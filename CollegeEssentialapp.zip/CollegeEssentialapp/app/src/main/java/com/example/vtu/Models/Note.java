package com.example.vtu.Models;

public class Note {
    private String id;
    private String note;

    public Note(String  id, String note) {
        this.id = id;
        this.note = note;
    }

    // Getter method for retrieving the note's ID
    public String getId() {
        return id;
    }

    // Setter method for setting the note's ID
    public void setId(String id) {
        this.id = id;
    }

    // Getter method for retrieving the content of the note
    public String getNote() {
        return note;
    }

    // Setter method for setting the content of the note
    public void setNote(String note) {
        this.note = note;
    }
}
