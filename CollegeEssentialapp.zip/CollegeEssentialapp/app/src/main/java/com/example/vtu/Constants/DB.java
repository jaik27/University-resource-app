package com.example.vtu.Constants;

public class DB {
    public static final String TABLE_NAME = "schedules";
    public static final String NOTES_TABLE_NAME = "notes";
}
